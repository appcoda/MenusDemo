//
//  ViewController.swift
//  Menus
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 AppCoda. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var scrollView: NSScrollView!
    
    @IBOutlet weak var imageView: NSImageView!
    
    
    // MARK: - Properties To Declare From Tutorial
    
    
    
    // MARK: - VC Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        configureScrollView()
        setupContextMenu()
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


    // MARK: - Methods Implementation
    
    func configureScrollView() {
        scrollView.allowsMagnification = true
        scrollView.magnification = 1.0
        scrollView.maxMagnification = 5.0
        scrollView.minMagnification = 0.25
    }
    
    
    // MARK: - Action Methods
    
    @objc func removeAppliedFilter() {
        guard let imageData = ImageHelper.shared.originalImageData else { return }
        imageView.image = NSImage(data: imageData)
    }
    
    
    @objc func dismissImage() {
        imageView.image = nil
        ImageHelper.shared.originalImageData = nil
        setupContextMenu()
    }
    
    
    // MARK: - IBAction Methods
    
    @IBAction func openImage(_ sender: Any) {
            guard let window = self.view.window else { return }
            let panel = NSOpenPanel()
            panel.canChooseFiles = true
            panel.canChooseDirectories = false
            panel.allowsMultipleSelection = false
            panel.allowedFileTypes = ["png", "jpg", "jpeg"]
            panel.beginSheetModal(for: window) { (response) in
                if response == NSApplication.ModalResponse.OK {
                    guard let data = ImageHelper.shared.loadImageData(fromURL: panel.url) else { return }
                    self.imageView.image = NSImage(data: data)
                    self.scrollView.magnify(toFit: self.imageView.frame)
                    self.setupContextMenu()
                }
            }
        }
    
    
    @IBAction func saveImage(_ sender: Any) {
            guard let imageData = imageView.image?.tiffRepresentation, let imageExtension = ImageHelper.shared.imageExtension, let window = self.view.window else { return }
                    
            let savePanel = NSSavePanel()
            savePanel.allowedFileTypes = [imageExtension]
            savePanel.canCreateDirectories = true
            savePanel.isExtensionHidden = false
            
            savePanel.beginSheetModal(for: window) { (response) in
                if response == NSApplication.ModalResponse.OK {
                    guard let targetURL = savePanel.url else { return }
                    ImageHelper.shared.save(imageData, toURL: targetURL)
                }
            }
        }
    
    
    // MARK: - Methods To Implement From Tutorial
    
    func setupContextMenu() {

    }
    
    
    
    // MARK: - Action Methods To Implement From Tutorial
    
    @objc func applyImageFilter(_ sender: NSMenuItem) {
        
    }
    
    
    @IBAction func handleZoomItem(_ sender: Any) {
        
    }
    
    
}

